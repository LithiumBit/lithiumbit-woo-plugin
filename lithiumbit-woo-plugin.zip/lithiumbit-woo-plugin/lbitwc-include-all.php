<?php
/*
LithiumBit for WooCommerce
https://github.com/LithiumBit/lithiumbit-woocommerce/
*/

//---------------------------------------------------------------------------
// Global definitions
if (!defined('LBITWC_PLUGIN_NAME'))
  {
  define('LBITWC_VERSION',           '0.01');

  //-----------------------------------------------
  define('LBITWC_EDITION',           'Standard');    

  //-----------------------------------------------
  define('LBITWC_SETTINGS_NAME',     'LBITWC-Settings');
  define('LBITWC_PLUGIN_NAME',       'LithiumBit for WooCommerce');   


  // i18n plugin domain for language files
  define('LBITWC_I18N_DOMAIN',       'lbitwc');

  }
//---------------------------------------------------------------------------

//------------------------------------------
// Load wordpress for POSTback, WebHook and API pages that are called by external services directly.
if (defined('LBITWC_MUST_LOAD_WP') && !defined('WP_USE_THEMES') && !defined('ABSPATH'))
   {
   $g_blog_dir = preg_replace ('|(/+[^/]+){4}$|', '', str_replace ('\\', '/', __FILE__)); // For love of the art of regex-ing
   define('WP_USE_THEMES', false);
   require_once ($g_blog_dir . '/wp-blog-header.php');

   // Force-elimination of header 404 for non-wordpress pages.
   header ("HTTP/1.1 200 OK");
   header ("Status: 200 OK");

   require_once ($g_blog_dir . '/wp-admin/includes/admin.php');
   }
//------------------------------------------


// This loads necessary modules
require_once (dirname(__FILE__) . '/libs/forknoteWalletdAPI.php');

require_once (dirname(__FILE__) . '/lbitwc-cron.php');
require_once (dirname(__FILE__) . '/lbitwc-utils.php');
require_once (dirname(__FILE__) . '/lbitwc-admin.php');
require_once (dirname(__FILE__) . '/lbitwc-render-settings.php');
require_once (dirname(__FILE__) . '/lbitwc-lithiumbit-gateway.php');

?>