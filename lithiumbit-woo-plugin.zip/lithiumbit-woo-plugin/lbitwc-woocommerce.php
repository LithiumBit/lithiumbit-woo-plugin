<?php
/*

Plugin Name: LithiumBit for WooCommerce
Plugin URI: https://github.com/LithiumBit/lithiumbit-woocommerce/
Description: LithiumBit for WooCommerce plugin allows you to accept payments in LithiumBits for physical and digital products at your WooCommerce-powered online store.
Version: 0.01
Author: KittyCatTech
Author URI: https://github.com/LithiumBit/lithiumbit-woocommerce/
License: BipCot NoGov Software License bipcot.org

*/


// Include everything
include (dirname(__FILE__) . '/lbitwc-include-all.php');

//---------------------------------------------------------------------------
// Add hooks and filters

// create custom plugin settings menu
add_action( 'admin_menu',                   'LBITWC_create_menu' );

register_activation_hook(__FILE__,          'LBITWC_activate');
register_deactivation_hook(__FILE__,        'LBITWC_deactivate');
register_uninstall_hook(__FILE__,           'LBITWC_uninstall');

add_filter ('cron_schedules',               'LBITWC__add_custom_scheduled_intervals');
add_action ('LBITWC_cron_action',             'LBITWC_cron_job_worker');     // Multiple functions can be attached to 'LBITWC_cron_action' action

LBITWC_set_lang_file();
//---------------------------------------------------------------------------

//===========================================================================
// activating the default values
function LBITWC_activate()
{
    global  $g_LBITWC__config_defaults;

    $lbitwc_default_options = $g_LBITWC__config_defaults;

    // This will overwrite default options with already existing options but leave new options (in case of upgrading to new version) untouched.
    $lbitwc_settings = LBITWC__get_settings ();

    foreach ($lbitwc_settings as $key=>$value)
    	$lbitwc_default_options[$key] = $value;

    update_option (LBITWC_SETTINGS_NAME, $lbitwc_default_options);

    // Re-get new settings.
    $lbitwc_settings = LBITWC__get_settings ();

    // Create necessary database tables if not already exists...
    LBITWC__create_database_tables ($lbitwc_settings);
    LBITWC__SubIns ();

    //----------------------------------
    // Setup cron jobs

    if ($lbitwc_settings['enable_soft_cron_job'] && !wp_next_scheduled('LBITWC_cron_action'))
    {
    	$cron_job_schedule_name = $lbitwc_settings['soft_cron_job_schedule_name'];
    	wp_schedule_event(time(), $cron_job_schedule_name, 'LBITWC_cron_action');
    }
    //----------------------------------

}
//---------------------------------------------------------------------------
// Cron Subfunctions
function LBITWC__add_custom_scheduled_intervals ($schedules)
{
	$schedules['seconds_30']     = array('interval'=>30,     'display'=>__('Once every 30 seconds'));
	$schedules['minutes_1']      = array('interval'=>1*60,   'display'=>__('Once every 1 minute'));
	$schedules['minutes_2.5']    = array('interval'=>2.5*60, 'display'=>__('Once every 2.5 minutes'));
	$schedules['minutes_5']      = array('interval'=>5*60,   'display'=>__('Once every 5 minutes'));

	return $schedules;
}
//---------------------------------------------------------------------------
//===========================================================================

//===========================================================================
// deactivating
function LBITWC_deactivate ()
{
    // Do deactivation cleanup. Do not delete previous settings in case user will reactivate plugin again...

    //----------------------------------
    // Clear cron jobs
    wp_clear_scheduled_hook ('LBITWC_cron_action');
    //----------------------------------
}
//===========================================================================

//===========================================================================
// uninstalling
function LBITWC_uninstall ()
{
    $lbitwc_settings = LBITWC__get_settings();

    if ($lbitwc_settings['delete_db_tables_on_uninstall'])
    {
        // delete all settings.
        delete_option(LBITWC_SETTINGS_NAME);

        // delete all DB tables and data.
        LBITWC__delete_database_tables ();
    }
}
//===========================================================================

//===========================================================================
function LBITWC_create_menu()
{

    // create new top-level menu
    // http://www.fileformat.info/info/unicode/char/e3f/index.htm
    add_menu_page (
        __('Woo LithiumBit', LBITWC_I18N_DOMAIN),                    // Page title
        __('LithiumBit', LBITWC_I18N_DOMAIN),                        // Menu Title - lower corner of admin menu
        'administrator',                                        // Capability
        'lbitwc-settings',                                        // Handle - First submenu's handle must be equal to parent's handle to avoid duplicate menu entry.
        'LBITWC__render_general_settings_page',                   // Function
        plugins_url('/images/lbit_16x.png', __FILE__)      // Icon URL
        );

    add_submenu_page (
        'lbitwc-settings',                                        // Parent
        __("WooCommerce LithiumBit Gateway", LBITWC_I18N_DOMAIN),                   // Page title
        __("General Settings", LBITWC_I18N_DOMAIN),               // Menu Title
        'administrator',                                        // Capability
        'lbitwc-settings',                                        // Handle - First submenu's handle must be equal to parent's handle to avoid duplicate menu entry.
        'LBITWC__render_general_settings_page'                    // Function
        );

}
//===========================================================================

//===========================================================================
// load language files
function LBITWC_set_lang_file()
{
    # set the language file
    $currentLocale = get_locale();
    if(!empty($currentLocale))
    {
        $moFile = dirname(__FILE__) . "/lang/" . $currentLocale . ".mo";
        if (@file_exists($moFile) && is_readable($moFile))
        {
            load_textdomain(LBITWC_I18N_DOMAIN, $moFile);
        }

    }
}
//===========================================================================

